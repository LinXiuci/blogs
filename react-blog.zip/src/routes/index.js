import webRoutes from './web'
import adminRoutes from './admin'

const routes = [
  adminRoutes,
  webRoutes

  // ..
]

export default routes
